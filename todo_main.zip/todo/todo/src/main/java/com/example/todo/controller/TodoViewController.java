package com.example.todo.controller;

import com.example.todo.entity.Todo;
import com.example.todo.repository.TodoRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class TodoViewController {
    private final TodoRepository todoRepository;
    public TodoViewController(TodoRepository todoRepository) {
        this.todoRepository = todoRepository;
    }
    // Landing page
    @GetMapping("/")
    public String index() {
        return "index";
    }
    // is used to Show all todos page
    @GetMapping("/todos")
    public String todos(Model model) {
        model.addAttribute("todos", todoRepository.findAll());
        return "todos";
    }
    // to Add new field
    @PostMapping("/todoNew")
    public String addTodo(@RequestParam String todoItem, @RequestParam String status) {
        Todo todo = new Todo();
        todo.setTodoItem(todoItem);
        todo.setCompleted("Yes".equalsIgnoreCase(status));
        todoRepository.save(todo);
        return "redirect:/todos";
    }
    // to Update
    @PostMapping("/todoUpdate/{id}")
    public String updateTodo(@PathVariable Long id) {
        todoRepository.findById(id).ifPresent(todo -> {
            todo.setCompleted(!todo.isCompleted());
            todoRepository.save(todo);
        });
        return "redirect:/todos";
    }
    // to Delete
    @PostMapping("/todoDelete/{id}")
    public String deleteTodo(@PathVariable Long id) {
        todoRepository.deleteById(id);
        return "redirect:/todos";
    }
}
